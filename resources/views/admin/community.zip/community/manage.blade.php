<x-app-layout>
<div class="space-y-8 admin-shell admin-community-page">

    <section class="admin-overview-hero">
        <div>
            <p class="admin-overview-hero__kicker">HallSync Admin</p>
            <h1 class="admin-overview-hero__title">Resident <span>Community Hub</span></h1>
            <span class="admin-overview-hero__subtitle">Review resident submissions, approve quality content, and maintain community standards.</span>
        </div>
    </section>

    {{-- STATS CARDS --}}
    @php
        $pendingCount = $pendingPosts->total();
        $approvedCount = $approvedPosts->count();
        $rejectedCount = $rejectedPosts->count();
        $totalCount = $pendingCount + $approvedCount + $rejectedCount;
    @endphp

    <div class="admin-feature-stat-grid admin-compact-stats admin-compact-stats-4">
        <x-admin-compact-stat icon="archive" :value="$totalCount" label="Total Posts" note="All time submissions" />
        <x-admin-compact-stat icon="clock" :value="$pendingCount" label="Pending Review" note="Awaiting moderation" tone="blue" />
        <x-admin-compact-stat icon="check" :value="$approvedCount" label="Published" note="Approved content" tone="green" />
        <x-admin-compact-stat icon="archive" :value="$rejectedCount" label="Rejected" note="Declined submissions" tone="red" />
    </div>

    <div class="admin-ticket-panel admin-ticket-archive admin-community-archive">
    {{-- TABS FOR DIFFERENT STATUSES --}}
    <nav class="admin-archive-tabs admin-community-tabs" role="tablist" aria-label="Community post statuses">
        <button type="button" onclick="filterByStatus('pending', this)" class="filter-tab active admin-archive-tab admin-community-tab is-active" data-community-tab="pending" role="tab" aria-selected="true">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 2" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
            </svg>
            Pending <span>{{ $pendingCount }}</span>
        </button>
        <button type="button" onclick="filterByStatus('approved', this)" class="filter-tab admin-archive-tab admin-community-tab" data-community-tab="approved" role="tab" aria-selected="false">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 6 9 17l-5-5" />
            </svg>
            Published <span>{{ $approvedCount }}</span>
        </button>
        <button type="button" onclick="filterByStatus('rejected', this)" class="filter-tab admin-archive-tab admin-community-tab" data-community-tab="rejected" role="tab" aria-selected="false">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 6 6 18M6 6l12 12" />
            </svg>
            Rejected <span>{{ $rejectedCount }}</span>
        </button>
    </nav>

    {{-- PENDING POSTS SECTION --}}
    <div id="pending-section" class="post-section">
        <div class="admin-community-review-panel" style="
            background: linear-gradient(180deg, #2A2C30 0%, #1F2023 100%);
            border-radius: 32px;
            padding: 28px 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4);
            border: 1px solid #3A342D;
        ">
            <div class="admin-brown-panel-head" style="display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom: 24px; flex-wrap: wrap;">
                <div>
                    <h2 style="
                        font-size: 24px;
                        font-weight: 600;
                        color: #F8F3EA;
                        font-family: 'Playfair Display', serif;
                        margin: 0;
                    ">
                        Posts Awaiting Review
                    </h2>
                    <p style="font-size: 12px; color: #8A7A66; margin-top: 4px;">Review and moderate resident submissions</p>
                </div>
                <div class="flex items-center gap-2">
                    <span class="admin-community-status admin-community-status-pending text-xs px-3 py-1 rounded-full" style="background: rgba(224,112,96,0.15); color: #E07060;">
                        {{ $pendingCount }} pending approval
                    </span>
                </div>
            </div>

            <div style="height:1px; background: linear-gradient(to right, rgba(214,168,91,0.3), rgba(214,168,91,0.05), transparent); margin-bottom: 24px;"></div>

            <div data-progressive-list>
            @forelse($pendingPosts as $post)
                <div class="post-item admin-community-review-card" data-progressive-item data-status="pending"
                     style="
                        background: linear-gradient(135deg, #2C2C2F 0%, #25272A 100%);
                        border: 1px solid rgba(58,52,45,0.6);
                        border-radius: 24px;
                        padding: 18px 20px;
                        margin-bottom: 12px;
                        transition: all 0.3s ease;
                     "
                     onmouseover="this.style.transform='translateX(4px)'; this.style.borderColor='rgba(214,168,91,0.4)'; this.style.boxShadow='0 12px 32px rgba(0,0,0,0.4)';"
                     onmouseout="this.style.transform='translateX(0)'; this.style.borderColor='rgba(58,52,45,0.6)'; this.style.boxShadow='none';">

                    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        <div class="flex-1">
                            <small class="admin-community-clean-meta">
                                POST #{{ $post->id }} &middot; {{ strtoupper(str_replace('_', ' ', $post->type)) }} &middot; {{ $post->created_at->format('M d, Y') }}
                            </small>
                            <h3 class="admin-community-clean-title">{{ $post->title }}</h3>
                            <p class="admin-community-clean-copy">{{ Str::limit($post->content, 100) }}</p>

                            <div class="admin-community-clean-hidden flex flex-wrap items-center gap-3 mb-3">
                                <div class="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style="background: rgba(214,168,91,0.12);">
                                    @if($post->type === 'lost_found') 🔍
                                    @elseif($post->type === 'buy_sell') 💰
                                    @elseif($post->type === 'event') 🎉
                                    @else 💬
                                    @endif
                                </div>
                                <div>
                                    <h3 style="font-size: 17px; font-weight: 700; color: #F8F3EA; margin: 0;">
                                        {{ $post->title }}
                                    </h3>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <span class="text-xs px-2 py-1 rounded-full" style="background: rgba(214,168,91,0.15); color: #D6A85B;">
                                            {{ strtoupper(str_replace('_', ' ', $post->type)) }}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <p class="admin-community-clean-hidden" style="font-size: 13px; color: #B0A898; line-height: 1.55; margin-bottom: 12px;">
                                {{ Str::limit($post->content, 100) }}
                            </p>

                            <div class="admin-community-clean-hidden flex flex-wrap items-center gap-3 text-xs" style="color: #8A7A66;">
                                <div class="flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                    {{ $post->user->name ?? 'Resident' }}
                                </div>
                                <div class="w-px h-3" style="background: #5A4A3A;"></div>
                                <div class="flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                    {{ $post->created_at->diffForHumans() }}
                                </div>
                            </div>
                        </div>

                        <div class="flex gap-2 flex-shrink-0 flex-wrap">
                            <a href="{{ route('community.show', $post) }}"
                               class="admin-community-action admin-community-action-secondary px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all duration-200 text-decoration-none"
                               style="background: rgba(214,168,91,0.12); color: #B47721; border: 1px solid rgba(214,168,91,0.22); text-decoration: none;"
                               onmouseover="this.style.background='rgba(214,168,91,0.2)'"
                               onmouseout="this.style.background='rgba(214,168,91,0.12)'">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                </svg>
                                View Details
                            </a>
                            <form method="POST" action="{{ route('community.approve', $post) }}">
                                @csrf
                                <button type="submit"
                                        class="admin-community-action admin-community-action-approve px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all duration-200"
                                        style="background: linear-gradient(135deg, #5A8A5A, #6DA76D); color: white; border: none;"
                                        onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 20px rgba(90,138,90,0.4)'"
                                        onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                    </svg>
                                    Approve
                                </button>
                            </form>
                            <button onclick="openRejectModal({{ $post->id }})" 
                                    class="admin-community-action admin-community-action-reject px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all duration-200"
                                    style="background: linear-gradient(135deg, #E07060, #D95B4F); color: white; border: none; cursor: pointer;"
                                    onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 20px rgba(224,112,96,0.4)'"
                                    onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                </svg>
                                Reject
                            </button>
                        </div>
                    </div>
                </div>
            @empty
                <div class="community-empty-state">
                    <strong>No pending posts</strong>
                    <p>All resident submissions have been reviewed.</p>
                </div>
            @endforelse
            </div>

            @if($pendingPosts->hasPages())
                <div style="margin-top: 32px;">
                    {{ $pendingPosts->links() }}
                </div>
            @endif
        </div>
    </div>

    {{-- APPROVED POSTS SECTION (Hidden by default) --}}
    <div id="approved-section" class="post-section" style="display: none;">
        <div class="admin-community-review-panel" style="
            background: linear-gradient(180deg, #2A2C30 0%, #1F2023 100%);
            border-radius: 32px;
            padding: 28px 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4);
            border: 1px solid #3A342D;
        ">
            <div class="admin-brown-panel-head" style="display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom: 24px;">
                <h2 style="font-size: 24px; font-weight: 600; color: #F8F3EA; font-family: 'Playfair Display', serif; margin: 0;">
                    Published Posts
                </h2>
                <span class="admin-community-status admin-community-status-published text-xs px-3 py-1 rounded-full" style="background: rgba(90,138,90,0.15); color: #5A8A5A;">
                    {{ $approvedCount }} published
                </span>
            </div>

            <div style="height:1px; background: linear-gradient(to right, rgba(214,168,91,0.3), rgba(214,168,91,0.05), transparent); margin-bottom: 24px;"></div>

            <div data-progressive-list>
            @forelse($approvedPosts as $post)
                <div class="approved-item admin-community-review-card" data-progressive-item style="
                    background: linear-gradient(135deg, #2C2C2F 0%, #25272A 100%);
                    border: 1px solid rgba(90,138,90,0.3);
                    border-radius: 20px;
                    padding: 20px 24px;
                    margin-bottom: 12px;
                    transition: all 0.3s ease;
                "
                onmouseover="this.style.transform='translateX(4px)'; this.style.borderColor='rgba(90,138,90,0.5)';">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <div class="flex items-center gap-3 mb-2">
                                <span class="text-lg">✅</span>
                                <h3 style="font-size: 16px; font-weight: 700; color: #F8F3EA;">{{ Str::limit($post->title, 60) }}</h3>
                                <span class="admin-community-status admin-community-status-published text-xs px-2 py-1 rounded-full" style="background: rgba(90,138,90,0.2); color: #5A8A5A;">Published</span>
                            </div>
                            <div class="text-sm" style="color: #B0A898;">
                                {{ Str::limit($post->content, 100) }}
                            </div>
                            <div class="text-xs mt-2" style="color: #8A7A66;">by {{ $post->user->name ?? 'Resident' }} • {{ $post->created_at->diffForHumans() }}</div>
                        </div>
                        <div class="flex gap-2 items-center justify-center flex-wrap">
                            <form method="POST" action="{{ route('community.destroy', $post) }}" data-confirm-message="Delete this post? This action cannot be undone." data-prevent-double-submit data-submitting-text="Deleting Post...">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="admin-community-action admin-community-action-danger px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200" style="background: rgba(224,112,96,0.15); color: #E07060; border: none; cursor: pointer;" onmouseover="this.style.background='rgba(224,112,96,0.25)'" onmouseout="this.style.background='rgba(224,112,96,0.15)'">
                                    🗑️ Delete
                                </button>
                            </form>
                            <a href="{{ route('community.show', $post) }}" class="admin-community-action admin-community-action-secondary px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 text-decoration-none" style="background: rgba(214,168,91,0.15); color: #D6A85B;" onmouseover="this.style.background='rgba(214,168,91,0.25)'" onmouseout="this.style.background='rgba(214,168,91,0.15)'">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
            @empty
                <div class="text-center py-12">
                    <p style="color: #8A7A66;">No published posts yet.</p>
                </div>
            @endforelse
            </div>
        </div>
    </div>

    {{-- REJECTED POSTS SECTION (Hidden by default) --}}
    <div id="rejected-section" class="post-section" style="display: none;">
        <div class="admin-community-review-panel" style="
            background: linear-gradient(180deg, #2A2C30 0%, #1F2023 100%);
            border-radius: 32px;
            padding: 28px 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4);
            border: 1px solid #3A342D;
        ">
            <div class="admin-brown-panel-head" style="display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom: 24px;">
                <h2 style="font-size: 24px; font-weight: 600; color: #F8F3EA; font-family: 'Playfair Display', serif; margin: 0;">
                    Rejected Posts
                </h2>
                <span class="admin-community-status admin-community-status-rejected text-xs px-3 py-1 rounded-full" style="background: rgba(224,112,96,0.15); color: #E07060;">
                    {{ $rejectedCount }} rejected
                </span>
            </div>

            <div style="height:1px; background: linear-gradient(to right, rgba(214,168,91,0.3), rgba(214,168,91,0.05), transparent); margin-bottom: 24px;"></div>

            <div data-progressive-list>
            @forelse($rejectedPosts as $post)
                <div class="rejected-item admin-community-review-card" data-progressive-item style="
                    background: linear-gradient(135deg, #2C2C2F 0%, #25272A 100%);
                    border: 1px solid rgba(224,112,96,0.3);
                    border-radius: 20px;
                    padding: 20px 24px;
                    margin-bottom: 12px;
                    transition: all 0.3s ease;
                ">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <div class="flex items-center gap-3 mb-2">
                                <span class="text-lg">❌</span>
                                <h3 style="font-size: 16px; font-weight: 700; color: #F8F3EA;">{{ Str::limit($post->title, 60) }}</h3>
                                <span class="admin-community-status admin-community-status-rejected text-xs px-2 py-1 rounded-full" style="background: rgba(224,112,96,0.2); color: #E07060;">Rejected</span>
                            </div>
                            <div class="text-sm" style="color: #B0A898;">
                                {{ Str::limit($post->content, 100) }}
                            </div>
                            @if($post->rejection_reason)
                                <div class="text-xs mt-2" style="color: #E07060;">
                                    Reason: {{ $post->rejection_reason }}
                                </div>
                            @endif
                            <div class="text-xs mt-2" style="color: #8A7A66;">by {{ $post->user->name ?? 'Resident' }} • {{ $post->created_at->diffForHumans() }}</div>
                        </div>
                        <div class="flex gap-2 items-center justify-center flex-wrap">
                            <form method="POST" action="{{ route('community.destroy', $post) }}" data-confirm-message="Delete this post? This action cannot be undone." data-prevent-double-submit data-submitting-text="Deleting Post...">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="admin-community-action admin-community-action-danger px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200" style="background: rgba(224,112,96,0.15); color: #E07060; border: none; cursor: pointer;" onmouseover="this.style.background='rgba(224,112,96,0.25)'" onmouseout="this.style.background='rgba(224,112,96,0.15)'">
                                    🗑️ Delete
                                </button>
                            </form>
                            <a href="{{ route('community.show', $post) }}" class="admin-community-action admin-community-action-secondary px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 text-decoration-none" style="background: rgba(214,168,91,0.15); color: #D6A85B;" onmouseover="this.style.background='rgba(214,168,91,0.25)'" onmouseout="this.style.background='rgba(214,168,91,0.15)'">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
            @empty
                <div class="community-empty-state">
                    <strong>No rejected posts</strong>
                    <p>Declined submissions will appear here.</p>
                </div>
            @endforelse
            </div>
        </div>
    </div>
    </div>

    {{-- REJECT MODAL --}}
    <div id="rejectModal" class="community-reject-modal" role="dialog" aria-modal="true" aria-hidden="true" aria-labelledby="reject-modal-title">
        <div class="community-reject-modal-card">
            <div class="community-reject-modal-head">
                <h3 id="reject-modal-title">Reject Post</h3>
                <button type="button" onclick="closeRejectModal()" class="community-reject-modal-close" aria-label="Close">&times;</button>
            </div>
            <form id="rejectForm" method="POST" data-prevent-double-submit data-submitting-text="Rejecting...">
                @csrf
                <label class="community-reject-label">
                    Reason for rejection
                    <span style="font-weight: 400; color: #9b8d81;">(optional, shown to resident)</span>
                </label>
                <textarea name="rejection_reason" rows="4" class="community-reject-textarea" placeholder="Describe why this post doesn't meet community guidelines…"></textarea>
                <div class="community-reject-actions">
                    <button type="submit" class="community-reject-btn community-reject-btn-confirm">Reject Post</button>
                    <button type="button" onclick="closeRejectModal()" class="community-reject-btn community-reject-btn-cancel">Cancel</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
let currentPostId = null;

function filterByStatus(status, activeButton = null) {
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.toggle('is-active', tab === activeButton);
        tab.classList.toggle('active', tab === activeButton);
        tab.setAttribute('aria-selected', tab === activeButton ? 'true' : 'false');
    });

    document.getElementById('pending-section').style.display = status === 'pending' ? 'block' : 'none';
    document.getElementById('approved-section').style.display = status === 'approved' ? 'block' : 'none';
    document.getElementById('rejected-section').style.display = status === 'rejected' ? 'block' : 'none';
}

function openRejectModal(postId) {
    currentPostId = postId;
    const form = document.getElementById('rejectForm');
    form.action = `/community/${postId}/reject`;
    const modal = document.getElementById('rejectModal');
    document.body.appendChild(modal);
    modal.setAttribute('aria-hidden', 'false');
    modal.classList.add('is-open');
    modal.querySelector('textarea')?.focus();
}

function closeRejectModal() {
    const modal = document.getElementById('rejectModal');
    modal.setAttribute('aria-hidden', 'true');
    modal.classList.remove('is-open');
    currentPostId = null;
}

document.getElementById('rejectModal').addEventListener('click', function(e) {
    if (e.target === this) closeRejectModal();
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') closeRejectModal();
});
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600;700&display=swap');
.admin-shell {
    max-width: 1580px;
    width: 100%;
    margin: 0 auto;
}
.admin-community-tabs {
    display: flex;
    flex-wrap: wrap;
    gap: 3px;
    margin: 0 0 20px;
    padding: 0;
    border: 1px solid rgba(107, 79, 58, 0.20);
    border-radius: 14px;
    background: var(--manager-record-panel, #fffdf9);
    overflow: hidden;
    box-shadow: 0 12px 24px rgba(79, 58, 44, 0.07);
}
.admin-community-tab {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 48px;
    padding: 12px 15px;
    border: 0;
    border-bottom: 2px solid transparent;
    border-radius: 0;
    background: transparent;
    color: var(--manager-content-body, #6f6255);
    font-family: 'Inter', system-ui, sans-serif;
    font-size: 0.82rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.18s ease, color 0.18s ease, border-color 0.18s ease;
}
.admin-community-tab svg {
    display: block;
    width: 16px;
    height: 16px;
    flex: 0 0 16px;
}
.admin-community-tab span {
    color: var(--manager-content-muted, #8a7a66);
}
.admin-community-tab:hover {
    background: rgba(15, 23, 42, 0.04);
    color: var(--manager-content-title, #342a23);
}
.admin-community-tab.is-active {
    border-bottom-color: #D6A85B;
    background: transparent;
    color: #D6A85B;
}
.admin-community-tab.is-active span {
    color: #D6A85B;
}
.admin-community-review-panel .admin-brown-panel-head h2 {
    color: #fff7ea ;
    font-family: 'Playfair Display', serif !important;
    font-size: 1.48rem !important;
    font-weight: 600 !important;
    line-height: 1.2 !important;
}
.admin-community-review-panel .admin-brown-panel-head p {
    color: rgba(255, 247, 234, 0.78) !important;
    font-family: 'Inter', system-ui, sans-serif !important;
    font-size: 0.92rem !important;
    font-weight: 400 !important;
    line-height: 1.55 !important;
}
.admin-community-review-card {
    border: 1px solid #e3d8ca !important;
    border-radius: 10px !important;
    background: #fbf8f3 !important;
    box-shadow: none !important;
    padding: 15px 16px !important;
}
.admin-community-review-card:hover {
    border-color: #d9c7af !important;
    background: #fffdf9 !important;
    box-shadow: none !important;
    transform: none !important;
}
.admin-community-clean-hidden {
    display: none !important;
}
.admin-community-clean-meta, .admin-community-clean-status {
    color: #9b8d81;
    font-size: .68rem;
    font-weight: 700;
    text-transform: uppercase;
}
.admin-community-clean-title {
    margin: 7px 0 4px;
    color: #342a23;
    font-family: 'Inter', sans-serif;
    font-size: .95rem;
    font-weight: 400;
    line-height: 1.35;
}
.admin-community-clean-copy {
    margin: 0;
    color: #786b60;
    font-size: .8rem;
    line-height: 1.55;
}
.admin-community-clean-status {
    width: 100%;
    color: #b47721;
    text-align: right;
}
.community-empty-state {
    padding: 36px 20px;
    text-align: center;
    border: 1px dashed rgba(214, 168, 91, 0.2);
    border-radius: 12px;
    background: rgba(248, 244, 237, 0.5);
}
.community-empty-state strong {
    display: block;
    color: #342a23;
    font-size: 1rem;
    font-weight: 700;
}
.community-empty-state p {
    margin: 6px 0 0;
    color: #786b60;
    font-size: 0.88rem;
}
.community-reject-modal {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 9000;
    background: rgba(10, 9, 7, 0.62);
    backdrop-filter: blur(4px);
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.community-reject-modal.is-open {
    display: flex;
}
.community-reject-modal-card {
    background: #fff;
    border: 1px solid #e3d8ca;
    border-radius: 20px;
    padding: 28px;
    max-width: 480px;
    width: 100%;
    box-shadow: 0 24px 60px rgba(48, 40, 32, 0.22);
}
.community-reject-modal-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}
.community-reject-modal-head h3 {
    margin: 0;
    color: #342a23;
    font-family: 'Playfair Display', serif;
    font-size: 1.35rem;
    font-weight: 700;
}
.community-reject-modal-close {
    background: transparent;
    border: 0;
    color: #786b60;
    cursor: pointer;
    font-size: 1.4rem;
    line-height: 1;
    padding: 4px;
    border-radius: 4px;
}
.community-reject-modal-close:hover {
    color: #342a23;
}
.community-reject-label {
    display: block;
    font-size: 0.78rem;
    font-weight: 700;
    color: #4c443b;
    margin-bottom: 8px;
    letter-spacing: 0.04em;
}
.community-reject-textarea {
    width: 100%;
    padding: 11px 13px;
    border: 1px solid #ddd5c9;
    border-radius: 10px;
    background: #fffdf9;
    color: #332d27;
    font: inherit;
    font-size: 0.88rem;
    line-height: 1.6;
    resize: vertical;
    min-height: 100px;
    outline: none;
    transition: border-color 0.18s ease, box-shadow 0.18s ease;
}
.community-reject-textarea:focus {
    border-color: #c3913c;
    box-shadow: 0 0 0 4px rgba(212, 164, 76, 0.14);
}
.community-reject-actions {
    display: flex;
    gap: 10px;
    margin-top: 18px;
    justify-content: flex-end;
}
.community-reject-btn {
    padding: 10px 20px;
    border-radius: 10px;
    font: inherit;
    font-size: 0.88rem;
    font-weight: 700;
    cursor: pointer;
    border: 0;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.community-reject-btn-confirm {
    background: #dc2626;
    color: #fff;
    box-shadow: 0 6px 16px rgba(220, 38, 38, 0.22);
}
.community-reject-btn-confirm:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 22px rgba(220, 38, 38, 0.3);
}
.community-reject-btn-cancel {
    background: #f7f3ee;
    color: #5a4e44;
    border: 1px solid #e3d8ca;
}
.community-reject-btn-cancel:hover {
    background: #ede7de;
}
.admin-community-review-card .admin-community-action {
    min-height: 44px;
    min-width: 44px;
    padding: 7px 10px !important;
    border-radius: 8px !important;
    box-shadow: none !important;
    font-size: .74rem !important;
    transform: none !important;
}
@media (max-width:1024px) {
    .admin-community-clean-status {
        text-align: left;
    }
}
.admin-shell > div:first-of-type {
    position: relative !important;
    overflow: hidden !important;
    border-radius: 20px !important;
    background: linear-gradient(120deg, #111009 0%, #1C1A12 50%, #201E14 100%) !important;
    border: 1px solid rgba(214, 168, 91, 0.18) !important;
    box-shadow: none !important;
}
.admin-shell > div:first-of-type::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image: linear-gradient(rgba(214, 168, 91, 0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(214, 168, 91, 0.04) 1px, transparent 1px);
    background-size: 48px 48px;
    pointer-events: none;
}
.admin-shell > div:first-of-type > div.absolute:first-child {
    top: -60px !important;
    right: -40px !important;
    width: 280px !important;
    height: 280px !important;
    background: radial-gradient(circle, rgba(214, 168, 91, 0.15) 0%, transparent 70%) !important;
    opacity: 1 !important;
    filter: none !important;
}
.admin-shell > div:first-of-type > div.absolute:nth-child(2) {
    display: none !important;
}
.admin-shell > div:first-of-type > div.relative {
    padding: 36px 44px !important;
}
.admin-shell > div:first-of-type > div.relative > div {
    align-items: center !important;
}
.admin-shell > div:first-of-type .mb-3 {
    margin-bottom: 12px !important;
}
.admin-shell > div:first-of-type .mb-3 span {
    display: inline-flex !important;
    align-items: center !important;
    gap: 8px !important;
    font-size: 0.875rem !important;
    letter-spacing: 0.18em !important;
    text-transform: uppercase !important;
    color: #d6a85b !important;
    font-weight: 700 !important;
}
.admin-shell > div:first-of-type .mb-3 span::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 999px;
    background: #d6a85b;
    display: inline-block;
}
.admin-shell > div:first-of-type h1 {
    color: #f0e9df !important;
    font-family: 'Playfair Display', serif !important;
    font-size: clamp(2.5rem, 4vw, 3.5rem) !important;
    font-weight: 700 !important;
    line-height: 1.12 !important;
    margin-bottom: 12px !important;
}
.admin-shell > div:first-of-type p {
    color: rgba(255, 255, 255, 0.62) !important;
    font-size: 1.125rem !important;
    max-width: 760px !important;
}
@media (max-width:768px) {
    .admin-shell > div:first-of-type > div.relative {
        padding: 24px !important;
    }
}
::-webkit-scrollbar {
    width: 6px;
}
::-webkit-scrollbar-track {
    background: #2A2C30;
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: linear-gradient(#D6A85B, #B8842F);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(#C49A4A, #A37222);
}
</style>
</x-app-layout>
